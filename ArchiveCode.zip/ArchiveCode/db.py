import sqlite3

DB_NAME = "scanner.db"


def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_path TEXT NOT NULL UNIQUE,
            file_name TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS symbols (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            file_id INTEGER,
            name TEXT NOT NULL,
            type TEXT,
            line_start INTEGER,
            line_end INTEGER,
            docstring TEXT,
            FOREIGN KEY (file_id) REFERENCES files (id)
        )
    ''')
    conn.commit()
    return conn


def save_file_data(conn, file_path, file_name, symbols):
    cursor = conn.cursor()
    try:
        cursor.execute('INSERT INTO files (file_path, file_name) VALUES (?, ?)', (file_path, file_name))
        file_id = cursor.lastrowid

        for sym in symbols:
            cursor.execute('''
                INSERT INTO symbols (file_id, name, type, line_start, line_end, docstring)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (file_id, sym['name'], sym['type'], sym['start'], sym['end'], sym['docstring']))

        conn.commit()
    except sqlite3.IntegrityError:
        print(f"File {file_name} already indexed.")

def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

