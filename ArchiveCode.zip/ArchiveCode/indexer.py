import ast
import os
from db import save_file_data


def parse_python_file(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        node = ast.parse(f.read())

    symbols = []

    for item in node.body:
        if isinstance(item, (ast.FunctionDef, ast.ClassDef)):
            docstring = ast.get_docstring(item)
            symbols.append({
                'name': item.name,
                'type': 'Class' if isinstance(item, ast.ClassDef) else 'Function',
                'start': item.lineno,
                'end': item.end_lineno,
                'docstring': docstring
            })

    return symbols


def index_folder(folder_path, conn):
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if file.endswith(".py"):
                full_path = os.path.join(root, file)
                print(f"Parsing: {full_path}")
                symbols = parse_python_file(full_path)
                save_file_data(conn, full_path, file, symbols)
