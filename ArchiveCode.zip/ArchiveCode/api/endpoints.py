from fastapi import APIRouter, Query
from db import get_db_connection

router = APIRouter(prefix="/api", tags=["Code Indexer"])

@router.get("/files")
def list_files():
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        SELECT f.id, f.file_name, f.file_path, 
               COUNT(CASE WHEN s.type = 'Function' THEN 1 END) as function_count
        FROM files f
        LEFT JOIN symbols s ON f.id = s.file_id
        GROUP BY f.id
    """
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

@router.get("/files/{name}/structure")
def get_file_structure(name: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    query = """
        SELECT s.name, s.type, s.line_start, s.line_end, s.docstring
        FROM symbols s
        JOIN files f ON s.file_id = f.id
        WHERE f.file_name = ?
    """
    cursor.execute(query, (name,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

@router.get("/search")
def search_symbols(q: str = Query(..., description="Key word for searching")):
    conn = get_db_connection()
    cursor = conn.cursor()
    search_pattern = f"%{q}%"
    query = """
        SELECT s.name, s.type, s.line_start, s.line_end, s.docstring, f.file_name
        FROM symbols s
        JOIN files f ON s.file_id = f.id
        WHERE s.name LIKE ? OR s.docstring LIKE ?
    """
    cursor.execute(query, (search_pattern, search_pattern))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]
