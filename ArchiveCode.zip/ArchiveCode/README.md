# "Архив кода" - API для навигации по кодовой базе

Маленький REST-сервис на Python, который умеет находить функции в коде по имени и описанию

---

## 📊 Схема базы данных (SQLite)

Проект использует реляционную структуру «один-ко-многим» (один файл может содержать много функций/классов).

### Таблица `files`
Содержит информацию о проиндексированных файлах.
* `id` (INTEGER, PK): Уникальный идентификатор файла.
* `file_path` (TEXT, UNIQUE): Полный путь к файлу.
* `file_name` (TEXT): Имя файла.

### Таблица `symbols`
Содержит информацию о классах и функциях внутри файлов.
* `id` (INTEGER, PK): Уникальный идентификатор сущности.
* `file_id` (INTEGER, FK): Ссылка на таблицу `files`.
* `name` (TEXT): Имя функции или класса.
* `type` (TEXT): Тип сущности (`Class` или `Function`).
* `line_start` (INTEGER): Номер строки начала.
* `line_end` (INTEGER): Номер строки конца.
* `docstring` (TEXT, NULL): Документация (строка описания).

---

## 🚀 Инструкция по запуску

### 1. Подготовка окружения
Убедитесь, что у вас установлен Python 3.12. Склонируйте проект и перейдите в его корневую директорию.

### 2. Установка зависимостей
Установите необходимые пакеты с помощью `pip`:
```bash
pip install -r requirements.txt
```

### 3. Индексация файлов (Шаг 1)
Перед запуском сервера необходимо наполнить базу данных. Скрипт обойдет папку с целевыми файлами и создаст `scanner.db`:
```bash
python indexer.py
```

### 4. Запуск REST API (Шаг 2)
Запустите сервер разработки Uvicorn:
```bash
uvicorn main:app --reload
```
После запуска интерактивная документация Swagger будет доступна по адресу: http://127.0.0.1:8000

---

## 🔍 Примеры запросов и ответов

### 1. Получить список файлов и количество функций в них
* **Запрос:** `GET /api/files`
* **Ответ (200 OK):**
```json
[
  {
        "id": 1,
        "file_name": "module_01_logger.py",
        "file_path": "./dataset\\module_01_logger.py",
        "function_count": 2
    },
    {
        "id": 2,
        "file_name": "module_02_manager.py",
        "file_path": "./dataset\\module_02_manager.py",
        "function_count": 2
    }
]
```

### 2. Получить полную структуру конкретного файла
* **Запрос:** `GET /api/files/module_01_logger.py/structure`
* **Ответ (200 OK):**
```json
[
    {
        "name": "format_data",
        "type": "Function",
        "line_start": 6,
        "line_end": 9,
        "docstring": "Automatically generated helper function."
    },
    {
        "name": "process_data",
        "type": "Function",
        "line_start": 12,
        "line_end": 15,
        "docstring": "Automatically generated helper function."
    },
    {
        "name": "LoggerProcessor",
        "type": "Class",
        "line_start": 18,
        "line_end": 30,
        "docstring": "Main entity class for Logger operations."
    }
]
```

### 3. Поиск по ключевому слову (регистронезависимый)
* **Запрос:** `GET /api/search?q=pRocess`
* **Ответ (200 OK):**
```json
[
   {
        "name": "process_data",
        "type": "Function",
        "line_start": 12,
        "line_end": 15,
        "docstring": "Automatically generated helper function.",
        "file_name": "module_01_logger.py"
    },
    {
        "name": "LoggerProcessor",
        "type": "Class",
        "line_start": 18,
        "line_end": 30,
        "docstring": "Main entity class for Logger operations.",
        "file_name": "module_01_logger.py"
    }
]
```
*(Примечание: Если по запросу ничего не найдено, эндпоинты возвращают пустой массив `[]`)*
